<?php   
    //Validar datos del servidor y la BD    
    $server="172.17.94.162";      
    $user = "useremote"; 
    $pass = "Admin$20";  
    $namedb="moodle";   
    //Crea la conexión con MYSQL
    $conn = mysqli_connect($server, $user, $pass, $namedb);
    mysqli_select_db($conn, $namedb);
    return $conn;    
    // Verificar conexión
    if ($conn->connect_error) {
        die("Error de Conexión: " . $conn->connect_error);
    } else {
        echo "Conexión exitosa";
}
?>