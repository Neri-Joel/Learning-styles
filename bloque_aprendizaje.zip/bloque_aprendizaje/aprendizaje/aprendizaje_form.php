<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Bloque de saludo al mundo: la vista de los campos
 *
 * @package   block_aprendizaje
 * @copyright 2024 Neri-Joel-Osorio-Mora
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once("{$CFG->libdir}/formslib.php");
require_once('../../config.php');

class aprendizaje_form extends moodleform {
    
    //Se utiliza para definir los elementos en el formulario, esta definición se utilizara para validar 
    //los datos enviados asi como para imprimir el formulario
    function definition() {
        
        // $mform =& $this->_form;
        // $mform->addElement('header', //Tipo de elemento que se agregará
        // 'displayinfo',               //Nombre de elemento a usar.
        // get_string('textfields', 'block_aprendizaje')); //Texto de la etiqueta del elemento.

        // $mform =& $this->_form; //Area de texto
        // $mform->addElement('textarea',
        //  'introduction', get_string('textfields', 'block_aprendizaje'), 'wrap="virtual" rows="15" cols="50"');

    }
}