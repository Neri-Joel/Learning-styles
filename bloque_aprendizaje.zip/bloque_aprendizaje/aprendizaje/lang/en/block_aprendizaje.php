<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Cadenas de idiomas en inglés
 *
 * @package   block_aprendizaje
 * @copyright 2024 Neri-Joel-Osorio-Mora
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Learning profile';//Nombre en el panel izq de moodle para agregar el bloque
$string['aprendizaje'] = 'Learning ProfileTITULO';
$string['aprendizaje:addinstance'] = 'Add a new Learning Profile block';
$string['aprendizaje:myaddinstance'] = 'Add a new Learning Profile to the My Moodle page';

//Variables descripción de bloque y copyright
$string['descripcion'] = 'Here you can see your results and know your type of learning<br></br>';
$string['copy_right'] = '<b><i><center>All rights reserved</b></i></center>'; //Cambia idioma a pie de pagina

//Variables de parametro cambio de Titulo
$string['blocktitle'] = 'Write the new tittle'; //Parametro y texto para cambiar titulo del bloque
$string['defaulttitle'] = 'Learning profile'; //Titulo por default
$string['defaulttext'] = '>Learning profile'; //Msj en caja de texto para cambiar titulo

//Variable de parametro y texto cambiar descripción del bloque
$string['blockstring'] = 'Change block description';

//Variable para agregar pagina
$string['addpage'] = 'See your results';
$string['textfields'] = 'Name';

//Titulo del formato de la pagina
$string['titulopagina'] = 'Your learning profile !';
