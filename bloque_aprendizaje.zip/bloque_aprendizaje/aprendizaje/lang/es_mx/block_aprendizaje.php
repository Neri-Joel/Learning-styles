<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Cadenas de idiomas en español
 *
 * @package   block_aprendizaje
 * @copyright 2024 Neri-Joel-Osorio-Mora
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


$string['pluginname'] = 'Perfil de aprendizaje'; //Nombre en el panel izq de moodle para agregar el bloque
$string['aprendizaje'] = 'Perfil de Aprendizaje';
$string['aprendizaje:addinstance'] = 'Añadir un bloque de Perfil de Aprendizaje';
$string['aprendizaje:myaddinstance'] = 'Añadir un bloque de Perfil de Aprendizaje en la página Mi Moodle';

//Variables descripción de bloque y copyright
$string['descripcion'] = 'Aqui puedes ver tus resultados y saber tu tipo de aprendizaje<br></br>';
$string['copy_right'] = '<b><i><center>Todos los derechos reservados</b></i></center>';//Cambia idioma a pie de pagina

//Variables de parametro cambio de Titulo
$string['blocktitle'] = 'Escribe el nuevo titulo del bloque'; //Parametro y texto para cambiar titulo del bloque
$string['defaulttitle'] = 'Perfil de aprendizaje'; //Titulo por default del bloque
$string['defaulttext'] = 'Perfil de aprendizaje'; //Msj en caja de texto para cambiar titulo

//Variable de parametro y texto cambiar descripción del bloque
$string['blockstring'] = 'Cambiar descripción del bloque';

//Variable para agregar pagina
$string['addpage'] = 'Ver resultados';
$string['textfields'] = 'Nombre';

//Titulo del formato de la pagina
$string['titulopagina'] = 'Tu perfil de aprendizaje!';
