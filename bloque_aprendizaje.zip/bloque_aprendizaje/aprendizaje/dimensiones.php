<?php
require_once('../../config.php');
global $USER;
include("conexionDB.php");
include ("sigmo.php");

$usuarios = "mdl_user";
$single = "mdl_questionnaire_resp_single";
$response = "mdl_questionnaire_response";
$choice = "mdl_questionnaire_quest_choice";
$userid = "$USER->id";
 
//CONSULTA PRIMERA DIMENSIÓN ACTIVO - REFLEXIVO
$consulta2 = mysqli_query($conn,"SELECT $single.question_id, $single.choice_id FROM $response 
INNER JOIN $usuarios ON $response.userid=$usuarios.id 
INNER JOIN $single ON $response.id=$single.response_id
WHERE $usuarios.id = '$userid' AND $single.question_id in (2,6,10,14,18,22,26,30,34,38,42)");

while($resultado2 = mysqli_fetch_array($consulta2)){
  if($resultado2 ['choice_id'] ==3){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==4) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==11){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==12) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==19){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==20) 
    $contadorB = $contadorB + 1; 

  if($resultado2 ['choice_id'] ==27){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==28) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==35){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==36) 
    $contadorB = $contadorB + 1; 

  if($resultado2 ['choice_id'] ==43){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==44) 
    $contadorB = $contadorB + 1; 

  if($resultado2 ['choice_id'] ==51){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==52) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==59){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==90) 
    $contadorB = $contadorB + 1; 

  if($resultado2 ['choice_id'] ==66){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==67) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==74){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==75) 
    $contadorB = $contadorB + 1;

  if($resultado2 ['choice_id'] ==82){
    $contadorA = $contadorA + 1;
    }else if ($resultado2 ['choice_id'] ==83) 
    $contadorB = $contadorB + 1;
}
  if($contadorA > $contadorB){
    $totalA = $contadorA - $contadorB;    
    }else{
    $totalB = $contadorB - $contadorA;    
  }
  echo "<br>";
  if($totalA == 1){ //1A
    $x = sigmoid(1);
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 1){ //1B
    $x = sigmoid(1);
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de: <b>".number_format($x,3,".",","),"</b>". '<br />';        
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br>
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R";
  }
  
  if($totalA == 3){//3A
    $x = sigmoid(2); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 3){ //3B
    $x = sigmoid(2); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de: <b>".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br> 
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R";
  }
    
  if($totalA == 5){ //5A
    $x = sigmoid(3); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 5){ //5B
    $x = sigmoid(3); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de:<b>".number_format($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br>
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R"; 
  }
    
  if($totalA == 7){ //7A
    $x = sigmoid(4); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 7){ //7B
    $x = sigmoid(4); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de:<b>".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br>
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R";    
  }
    
  if($totalA == 9){ //9A
    $x = sigmoid(5);
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 9){ //9B
    $x = sigmoid(5);
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de:<b>".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br>
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R";    
  }
    
  if($totalA == 11){ //11A
    $x = sigmoid(6); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Activo</i></b> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Lo que indica que, aprendes mejor nueva información cuando ensayas, aplicas y experimentas con ella.<br>
    Tienes agrado por trabajar en equipo ya que te permite explicar y discutir la información obtenida.</i>". '<br />';
    $combA = "A";

  }else if ($totalB == 11){ //11B
    $x = sigmoid(6); 
    echo "<br>"; 
    echo "<b>Dimensión Activo - Reflexivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Reflexivo</i></b> es de:<b>".number_format($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Lo que indica que, comprendes mejor la información cuando trabajas de manera individual,<br>
    ya que, tu aprendizaje se basa en pensar, meditar, reflexionar y clasificar la información.</i>". '<br />';
    $combR = "R"; 
    }
          
//CONSULTA SEGUNDA DIMENSIÓN SENSITIVO - INTUITIVO
$consulta1 = mysqli_query($conn,"SELECT $single.question_id, $single.choice_id FROM $response 
INNER JOIN $usuarios ON $response.userid=$usuarios.id 
INNER JOIN $single ON $response.id=$single.response_id
WHERE $usuarios.id = '$userid' AND $single.question_id in (3,7,11,15,19,23,27,31,35,39,43)");

while($resultado1 = mysqli_fetch_array($consulta1)){

  if($resultado1 ['choice_id'] ==5){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==6) 
    $contB = $contB + 1;

  if($resultado1 ['choice_id'] ==13){
    $contA  = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==14) 
    $contB = $contB + 1;

  if($resultado1 ['choice_id'] ==21){
    $contA  = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==22) 
    $contB = $contB + 1; 

  if($resultado1 ['choice_id'] ==29){
    $contA  = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==30) 
    $contB = $contB + 1;

 if($resultado1 ['choice_id'] ==37){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==38) 
    $contB = $contB + 1; 

 if($resultado1 ['choice_id'] ==45){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==46) 
    $contB = $contB + 1; 

 if($resultado1 ['choice_id'] ==53){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==54) 
    $contB = $contB + 1;

 if($resultado1 ['choice_id'] ==60){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==61) 
    $contB = $contB + 1; 

 if($resultado1 ['choice_id'] ==68){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==69) 
    $contB = $contB + 1;

 if($resultado1 ['choice_id'] ==76){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==77) 
    $contB = $contB + 1;

 if($resultado1 ['choice_id'] ==84){
    $contA = $contA + 1;
    }else if ($resultado1 ['choice_id'] ==85) 
    $contB = $contB + 1;
  } 
echo "<br>";

  if($contA > $contB){
    $varA = $contA - $contB;
    }else {
    $varB = $contB - $contA;
    }      

  if($varA == 1){ //1A
    $x = sigmoid(1);      
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
    }else if ($combRS = $combR){
        $combRS = $combR .'S';
    }

  }else if ($varB == 1){ //1B
    $x = sigmoid(1);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

  if($varA == 3){ //3A
    $x = sigmoid(2);      
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
  }else if ($combRS = $combR){
        $combRS = $combR .'S';
  }

  }else if ($varB == 3) { //3B
    $x = sigmoid(2);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

  if($varA == 5){ //5A
    $x = sigmoid(3);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
  }else if ($combRS = $combR){
        $combRS = $combR .'S';
  }

  }else if ($varB == 5){ //5B
    $x = sigmoid(3);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';  
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';  
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

  if($varA == 7){ //7A
    $x = sigmoid(4); 
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';  
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
  }else if ($combRS = $combR){
        $combRS = $combR .'S';
  }

  }else if ($varB == 7){ //7B
    $x = sigmoid(4);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';  
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';  
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

  if($varA == 9){ //9A
    $x = sigmoid(5);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
  }else if ($combRS = $combR){
        $combRS = $combR .'S';
  }

  }else if ($varB == 9){ //9B
    $x = sigmoid(5); 
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI  
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

  if($varA == 11){ //11A
    $x = sigmoid(6); 
    echo "<br>"; 
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Sensitivo</b></i> es de: <b>" .number_format ($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Tienes un aprendizaje practico, experimental y concreto, ya que memorizas hechos y datos con facilidad,<br>
    resuelves problemas siguiendo procedimientos bien establecidos, cuidadoso en los detalles.</i>". '<br />';
    //combinacion AS,RS
    if ($combAS = $combA){
        $combAS = $combA.'S';
  }else if ($combRS = $combR){
        $combRS = $combR .'S';
  }

  }else if ($varB == 11){ //11B
    $x = sigmoid(6);
    echo "<b>Dimensión Sensitivo - Intuitivo</b>". '<br />';  
    echo "El grado de pertenencia al polo <b><i>Intuitivo</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Comprendes mejor mediante la reflexión, ideas y teorías, la cual te permite comprender con facilidad nuevos<br>
    conceptos y significados, no te gustan las actividades que requieren mucha memorización o cálculos rutinarios.</i>". '<br />';
    //combinacion AI,RI
    if ($combAI = $combA){
        $combAI = $combA.'I';
  }else if ($combRI = $combR){
        $combRI = $combR .'I';
  } 
}

//CONSULTA TERCERA DIMENSIÓN VISUAL - VERBAL
$consult = mysqli_query($conn,"SELECT $single.question_id,  $single.choice_id FROM $response
INNER JOIN $usuarios ON $response.userid=$usuarios.id 
INNER JOIN $single ON $response.id=$single.response_id
WHERE $usuarios.id = '$userid' AND $single.question_id in (4,8,12,16,20,24,28,32,36,40,44)");

while($result = mysqli_fetch_array($consult)){

  if($result ['choice_id'] ==7){
    $contaA = $contaA + 1;
    } else if ($result ['choice_id'] ==8) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==15){
    $contaA  = $contaA + 1;
    } else if ($result ['choice_id'] ==16) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==23){
    $contaA  = $contaA + 1;
    }else if ($result ['choice_id'] ==24) 
    $contaB = $contaB + 1; 

  if($result ['choice_id'] ==31){
    $contaA  = $contaA + 1;
    }else if ($result ['choice_id'] ==32) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==39){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==40) 
    $contaB = $contaB + 1; 

  if($result ['choice_id'] ==47){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==48) 
    $contaB = $contaB + 1; 

  if($result ['choice_id'] ==55){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==56) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==62){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==63) 
    $contaB = $contaB + 1; 

  if($result ['choice_id'] ==70){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==71) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==78){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==79) 
    $contaB = $contaB + 1;

  if($result ['choice_id'] ==86){
    $contaA = $contaA + 1;
    }else if ($result ['choice_id'] ==87) 
    $contaB = $contaB + 1;
  }   

  if($contaA > $contaB) {
    $variA = $contaA - $contaB;
    }else {
    $variB = $contaB - $contaA;
  }
  echo "<br>";
  if($variA == 1){ //1A
    $x = sigmoid(1);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</b></i>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
  }else{
        $combRIV = $combRI .'V';
    }
    
  }else if ($variB == 1){ //1B
    $x = sigmoid(1);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
     //combinacion ASVE,AIVE,RSVE,RIVE
     if ($combASVE = $combAS){
         $combASVE = $combAS.'VE';
  }else if ($combAIVE = $combAI){
         $combAIVE = $combAI .'VE';
  }else if ($combRSVE = $combRS){
         $combRSVE = $combRS .'VE';
  }else{
         $combRIVE = $combRI .'VE';
    }
  }

  if($variA == 3){ //3A
    $x = sigmoid(2);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</b></i>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
    //echo $combASV. '<br />';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
    //echo $combAIV. '<br />';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
    //echo $combRSV. '<br />';
  }else{
        $combRIV = $combRI .'V';
    //echo $combRIV. '<br />';
  }

  }else if ($variB == 3){ //3B
    $x = sigmoid(2);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
    //combinacion ASVE,AIVE,RSVE,RIVE
    if ($combASVE = $combAS){
        $combASVE = $combAS.'VE';
    //echo $combASVE. '<br />';
  }else if ($combAIVE = $combAI){
        $combAIVE = $combAI .'VE';
    //echo $combRS. '<br />';
  }else if ($combRSVE = $combRS){
        $combRSVE = $combRS .'VE';
    //echo $combRSVE. '<br />';
  }else{
        $combRIVE = $combRI .'VE';
    //echo $combRIVE. '<br />';
    }
  }

  if($variA == 5){ //5A
    $x = sigmoid(3);
    //echo "<br>";
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</i></b>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
  }else{
        $combRIV = $combRI .'V';
    }

  }else if ($variB == 5){ //5B
    $x = sigmoid(3);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
    //combinacion ASVE,AIVE,RSVE,RIVE
    if ($combASVE = $combAS){
        $combASVE = $combAS.'VE';
  }else if ($combAIVE = $combAI){
        $combAIVE = $combAI .'VE';
  }else if ($combRSVE = $combRS){
        $combRSVE = $combRS .'VE';
  }else{
        $combRIVE = $combRI .'VE';
    }
  }

  if($variA == 7){ //7A
    $x = sigmoid(4);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</i></b>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
  }else{
        $combRIV = $combRI .'V';
    }
    
  }else if ($variB == 7){ //7B
    $x = sigmoid(4);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
    //combinacion ASVE,AIVE,RSVE,RIVE
    if ($combASVE = $combAS){
        $combASVE = $combAS.'VE';
  }else if ($combAIVE = $combAI){
        $combAIVE = $combAI .'VE';
  }else if ($combRSVE = $combRS){
        $combRSVE = $combRS .'VE';
  }else{
        $combRIVE = $combRI .'VE';
    }
  }

  if($variA == 9){ //9A
    $x = sigmoid(5);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</i></b>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
  }else{
        $combRIV = $combRI .'V';
    }

  }else if ($variB == 9){ //9B
    $x = sigmoid(5);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
    //combinacion ASVE,AIVE,RSVE,RIVE
    if ($combASVE = $combAS){
        $combASVE = $combAS.'VE';
  }else if ($combAIVE = $combAI){
        $combAIVE = $combAI .'VE';
  }else if ($combRSVE = $combRS){
        $combRSVE = $combRS .'VE';
  }else{
        $combRIVE = $combRI .'VE';
    }
  }

  if($variA == 11){ //11A
    $x = sigmoid(6);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Visual</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Tu aprendizaje y comprensión de nuevo conocimiento se basa en la representación visual de la información,<br>
    como diagramas, imágenes, diagramas etc. <b>¡Recuerdas mejor lo que ves!</i></b>". '<br />';
    //combinacion ASV,AIV,RSV,RIV
    if ($combASV = $combAS){
        $combASV = $combAS.'V';
  }else if ($combAIV = $combAI){
        $combAIV = $combAI .'V';
  }else if ($combRSV = $combRS){
        $combRSV = $combRS .'V';
  }else{
        $combRIV = $combRI .'V';
    }

  }else if ($variB == 11){ //11B
    $x = sigmoid(6);
    echo "<b>Dimensión Visual - Verbal</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Verbal</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';
    echo "<i>Tu aprendizaje se basa en las explicaciones verbales, aprendes mejor con el uso de la expresión oral y escrita,<br>
    como los debates, discusiones o lluvias de ideas. <b>¡Recuerdas mejor lo que escuchas!</i></b>". '<br />';
    //combinacion ASVE,AIVE,RSVE,RIVE
    if ($combASVE = $combAS){
        $combASVE = $combAS.'VE';
  }else if ($combAIVE = $combAI){
        $combAIVE = $combAI .'VE';
  }else if ($combRSVE = $combRS){
        $combRSVE = $combRS .'VE';
  }else{
        $combRIVE = $combRI .'VE';
    }
  }    

//CONSULTA CUARTA DIMENSIÓN SECUENCIAL - GLOBAL
$consult4 = mysqli_query($conn,"SELECT $single.question_id, $single.choice_id FROM $response
INNER JOIN $usuarios ON $response.userid=$usuarios.id 
INNER JOIN $single ON $response.id=$single.response_id
WHERE $usuarios.id = '$userid' AND $single.question_id in (5,9,13,17,21,25,29,33,37,41,45)");

while($result4 = mysqli_fetch_array($consult4)){

  if($result4 ['choice_id'] ==9){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==10) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==17){
    $contadA  = $contadA + 1;
    }else if ($result4 ['choice_id'] ==18) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==25){
    $contadA  = $contadA + 1;
    }else if ($result4 ['choice_id'] ==26) 
    $contadB = $contadB + 1; 

  if($result4 ['choice_id'] ==33){
    $contadA  = $contadA + 1;
    }else if ($result4 ['choice_id'] ==34) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==41){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==42) 
    $contadB = $contadB + 1; 

  if($result4 ['choice_id'] ==49){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==50) 
    $contadB = $contadB + 1; 

  if($result4 ['choice_id'] ==57){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==58) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==64){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==65) 
    $contadB = $contadB + 1; 

  if($result4 ['choice_id'] ==72){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==73) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==80){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==81) 
    $contadB = $contadB + 1;

  if($result4 ['choice_id'] ==88){
    $contadA = $contadA + 1;
    }else if ($result4 ['choice_id'] ==89) 
    $contadB = $contadB + 1;
  }

  if($contadA > $contadB){
    $variablA = $contadA - $contadB;
    }else {
    $variablB = $contadB - $contadA;
  }
  echo "<br>";
  if($variablA == 1){ //1A
    $x = sigmoid(1); 
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES
    if ($combASVS = $combASV){
        $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
          $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
          $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
          $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
          $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
          $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
          $comb_final = $combRIV .'S';
    }else{
          $comb_final = $combRIVE .'S';
    }
      
  }else if ($variablB == 1){ //1B
    $x = sigmoid(1);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';  
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>". '<br />';
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }

  if($variablA == 3){ //3A
    $x = sigmoid(2);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />'; 
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES        
    if ($combASVS = $combASV){
        $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
        $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
        $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
        $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
        $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
        $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
        $comb_final = $combRIV .'S';
    }else{
        $comb_final = $combRIVE .'S';
    }    

  }else if ($variablB == 3){ //3B
    $x = sigmoid(2);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';  
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>". '<br />';
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }

  if($variablA == 5){ //5A
    $x = sigmoid(3);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES
    if ($combASVS = $combASV){
      $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
      $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
      $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
      $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
      $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
      $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
      $comb_final = $combRIV .'S';
    }else{
      $comb_final = $combRIVE .'S';
    }

  }else if ($variablB == 5){ //5B
    $x = sigmoid(3);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>". '<br />';
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }

  if($variablA == 7){ //7A
    $x = sigmoid(4);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES
    if ($combASVS = $combASV){
        $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
        $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
        $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
        $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
        $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
        $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
        $comb_final = $combRIV .'S';
    }else{
        $comb_final = $combRIVE .'S';
    }

  }else if ($variablB == 7){ //7B
    $x = sigmoid(4);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />'; 
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>". '<br />';
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }

  if($variablA == 9){ //9A
    $x = sigmoid(5);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';   
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES
    if ($combASVS = $combASV){
        $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
        $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
        $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
        $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
        $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
        $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
        $comb_final = $combRIV .'S';
    }else{
        $comb_final = $combRIVE .'S';
    }

  }else if ($variablB == 9){ //9B
    $x = sigmoid(5);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';   
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>". '<br />';
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }

  if($variablA == 11){ //11A
    $x = sigmoid(6);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Secuencial</b></i> es de: <b> " .number_format ($x,3,".",","),"</b>". '<br />';  
    echo "<i>Comprendes mejor la información cuando se te presenta de una menara lógica y ordenada con aumentos en la complejidad,<br>
    cuentas con razonamiento lineal y pasos lógicos para solucionar problemas, lo cual te hace fuerte en el pensamiento y el análisis.</i></b>". '<br />';
    //combinacion ASVS,ASVES,AIVS,AIVES,RSVS,RSVES,RIVS,RIVES
    if ($combASVS = $combASV){
        $comb_final = $combASV.'S';
    }else if ($combASVES = $combASVE){
        $comb_final = $combASVE .'S';
    }else if ($combAIVS = $combAIV){
        $comb_final = $combAIV .'S';
    }else if ($combAIVES = $combAIVE){
        $comb_final = $combAIVE .'S';
    }else if ($combRSVS = $combRSV){
        $comb_final = $combRSV .'S';
    }else if ($combRSVES = $combRSVE){
        $comb_final = $combRSVE .'S';
    }else if ($combRIVS = $combRIV){
        $comb_final = $combRIV .'S';
    }else{
        $comb_final = $combRIVE .'S';
    } 

  }else if ($variablB == 11){ //11B
    $x = sigmoid(6);
    echo "<b>Dimensión Secuencial - Global</b>". '<br />';
    echo "El grado de pertenencia al polo <b><i>Global</b></i> es de: <b> ".number_format($x,3,".",","),"</b>". '<br />';  
    echo "<i>Reflejas el progreso de tu aprendizaje resolviendo problemas complejos con facilidad y a su vez<br>
    comprendes la información y material rápidamente.</i></b>";
    //combinacion ASVG,ASVEG,AIVG,AIVEG,RSVG,RSVEG,RIVG,RIVEG
    if ($combASVG = $combASV){
        $comb_final = $combASV.'G';  
    }else if ($combASVEG = $combASVE){
        $comb_final = $combASVE .'G';
    }else if ($combAIVG = $combAIV){
        $comb_final = $combAIV .'G';
    }else if ($combAIVEG = $combAIVE){
        $comb_final = $combAIVE .'G';
    }else if ($combRSVG = $combRSV){
        $comb_final = $combRSV .'G';
    }else if ($combRSVEG = $combRSVE){
        $comb_final = $combRSVE .'G';
    }else if ($combRIVG = $combRIV){
        $comb_final = $combRIV .'G';
    }else{
        $comb_final = $combRIVE .'G';
      }    
    }
  echo "<br>";
  echo "<center><b><i>De auerdo al analisis realizado sobre tú perfil de aprendizaje $comb_final, te recomendamos<br>
  revizar los contenidos y actividades que se encuentran en el curso ''Conceptos básicos de JAVA'' 
  adecuados <br/>a tu perfil de aprendizaje los cuales potenciaran tu entendimiento
  sobre el tema Variables y Constantes.</i></b></center>. <br />";
  echo '<center><b><i> ** IMPORTANTE ** </center></b></i>';
  echo '<center><b><i>Si es la primera vez que entras a tu perfil de aprendizaje es necesario que vuelvas a iniciar sesión<br>
  para poder visualizar los contenidos y materiales sugeridos.</center></b></i>. <br />';
  echo'<h5><center><a href="http://172.17.94.162/moodle/course/view.php?id=8"><i><b>Ver contenidos y actividades</h5></center></a></b></i>';

  //Actualiza el campo idnumber y agrega la combinación obtenida
  $conn -> query("UPDATE mdl_user SET idnumber = '$comb_final' WHERE $usuarios.id = '$userid'");
  mysqli_close($conn);
  ?>